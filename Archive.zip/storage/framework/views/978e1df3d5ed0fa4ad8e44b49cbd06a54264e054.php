<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a
                                    href="javascript: void(0);"><?php echo e(config('app.name', 'Manyyu')); ?></a></li>
                            <li class="breadcrumb-item active">Users Data</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Users Data</h4>
                </div>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.index')->html();
} elseif ($_instance->childHasBeenRendered('m1NB2Ur')) {
    $componentId = $_instance->getRenderedChildComponentId('m1NB2Ur');
    $componentTag = $_instance->getRenderedChildComponentTagName('m1NB2Ur');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('m1NB2Ur');
} else {
    $response = \Livewire\Livewire::mount('user.index');
    $html = $response->html();
    $_instance->logRenderedChild('m1NB2Ur', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

        <script>
            window.addEventListener('openModal', event => {
                $("#custom-modal").modal('show');

            });
            window.addEventListener('closeModal', event => {
                $("#custom-modal").modal('hide');

            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#custom-modal").on('hidden.bs.modal', function() {
                    livewire.emit('forceCloseModal');
                });
            });
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Users Data'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/pages/users.blade.php ENDPATH**/ ?>