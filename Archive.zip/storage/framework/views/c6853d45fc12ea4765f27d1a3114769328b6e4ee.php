<div class="row">
    <div class="col-4">
        <div class="card-box">
            <h4 class="card-title">Add User</h4>
            <div class="form-group">
                <label>User Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="e.g : Udin" wire:model="name">
            </div>
            <div class="form-group">
                <label>User Picture<span class="text-danger">*</span></label>
                <input class="form-control" type="file" id="formFile" wire:model="photo">
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
            </div>
            <div class="form-group">
                <label>User Contact <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="e.g : 0899xxxx" wire:model="phone">
            </div>
            <div class="form-group">
                <label>User Address <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="e.g : Bps Sudiang" wire:model="address">
            </div>

            <div class="row mt-3">
                <div class="col-12">
                    <div class="text-right">
                        <button type="button" class="btn w-sm btn-light waves-effect">Cancel</button>
                        <button type="button" class="btn w-sm btn-success waves-effect waves-light">Save</button>
                        <button type="button" class="btn w-sm btn-danger waves-effect waves-light">Delete</button>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>

    </div>
    <div class="col-8">
        <div class="card-box">
            <h4 class="card-title">Users Table</h4>

        </div>
    </div>
</div>
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/wireuser.blade.php ENDPATH**/ ?>