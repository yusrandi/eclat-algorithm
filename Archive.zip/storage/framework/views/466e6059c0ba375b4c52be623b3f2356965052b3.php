<!-- App css -->
<link href="<?php echo e(asset('assets/css/bootstrap-creative.min.css')); ?>" rel="stylesheet" type="text/css"
    id="bs-default-stylesheet" />
<link href="<?php echo e(asset('assets/css/app-creative.min.css')); ?>" rel="stylesheet" type="text/css"
    id="app-default-stylesheet" />

<link href="<?php echo e(asset('assets/css/bootstrap-creative-dark.min.css')); ?>" rel="stylesheet" type="text/css"
    id="bs-dark-stylesheet" disabled />
<link href="<?php echo e(asset('assets/css/app-creative-dark.min.css')); ?>" rel="stylesheet" type="text/css"
    id="app-dark-stylesheet" disabled />

<!-- icons -->
<link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/dropzone/min/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php echo $__env->yieldContent('css'); ?>
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/layouts/shared/head-css.blade.php ENDPATH**/ ?>