<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <div class="dropdown float-right">
                <a href="#" class="dropdown-toggle arrow-none card-drop" data-toggle="dropdown" aria-expanded="false">
                    <i class="mdi mdi-dots-vertical"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Sales Report</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Export Report</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Profit</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Action</a>
                </div>
            </div>

            <div class="form-group row mb-3 mt-3">

                <div class="col-6">
                    <label for="">Minimum Nilai Support</label>
                    <input wire:model="minSupport" type="number" class="form-control " id="inputPassword3"
                        placeholder="Min nilai Support ">
                </div>

                <div class="col-6">
                    <label for="">Minimum Nilai Confidence</label>
                    <input wire:model="minCf" type="number" class="form-control " id="inputPassword3"
                        placeholder="Min Nilai Confidence">
                </div>

            </div>

            <?php if($trans->count()): ?>
                <h4>Transaksi Awal</h4>
                <div class="table-responsive">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                            <tr>
                                <th>TID</th>
                                <th>Item</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                if ($index != 0) {
                                                    echo ', ';
                                                }
                                                echo $item->product->name;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <h4>Transaksi Vertical</h4>
                <div class="table-responsive">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                            <tr>
                                <th>Itemset</th>
                                <th>TID List</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($items->name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $items->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                if ($index != 0) {
                                                    echo ', ';
                                                }
                                                echo $item->kode;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <h4>Hasil Penyilangan 2 Itemset</h4>
                <div class="table-responsive">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                            <tr>
                                <th width="30%">Itemset</th>
                                <th width="30%">TID List</th>
                                <th>Support</th>
                                <th>Confidence</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item1->id != $item2->id): ?>

                                        <?php
                                            $count = 0;
                                            $total = count($trans);
                                            $tdlist = [];
                                            foreach ($trans as $keyTrans => $items) {
                                                $tr_value = [];
                                                foreach ($items as $key => $value) {
                                                    $tr_value[$key] = $value['product_id'];
                                                }
                                                if (in_array($item1->id, $tr_value) & in_array($item2->id, $tr_value)) {
                                                    $count++;
                                                    // echo $keyTrans . ', ';
                                                    $tdlist[] = $keyTrans;
                                                }
                                            }
                                            
                                            $count1 = count($alltrans->where('product_id', $item1->id));
                                            $count2 = count($alltrans->where('product_id', $item2->id));
                                        ?>



                                        <?php if($count > 0): ?>
                                            <?php if(($minSupport < number_format(($count / $total) * 100)) & ($minCf <
                                                number_format(($count / $count2) * 100))): ?> <tr>
                                                <td><?php echo e($item1->name . ', ' . $item2->name); ?>

                                                <td>
                                                    <?php $__currentLoopData = $tdlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($item . ', '); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e('(' . $count . '/' . $total . ') * 100 = ' . number_format(($count / $total) * 100) . '%'); ?>

                                                </td>
                                                <td><?php echo e('(' . $count . '/' . $count2 . ') * 100 = ' . number_format(($count / $count2) * 100) . '%'); ?>

                                                </td>
                                                </tr>
                                        <?php endif; ?>

                                    <?php endif; ?>

                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
        
        <div class="table-responsive" hidden>
            <table id="datatable-buttons" class="table table-hover">
                <thead>
                    <tr>
                        <th>Itemset</th>
                        <th>Jumlah</th>
                        <th>Trx</th>
                        <th>Support</th>
                        <th>Confidence</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item1->id != $item2->id && $item1->id != $item3->id): ?>
                                    <?php if($item2->id != $item3->id): ?>

                                        <?php
                                            $itemValue = $item1->id . ',' . $item2->id . ',' . $item3->id;
                                            $count = 0;
                                            $countDan = 0;
                                            $total = count($trans);
                                            foreach ($trans as $key => $items) {
                                                $tr_value = [];
                                                foreach ($items as $key => $value) {
                                                    $tr_value[$key] = $value['product_id'];
                                                }
                                                if (in_array($item1->id, $tr_value) & in_array($item2->id, $tr_value) & in_array($item3->id, $tr_value)) {
                                                    // echo ' true';
                                                    $count++;
                                                }
                                                if (in_array($item1->id, $tr_value) & in_array($item2->id, $tr_value)) {
                                                    // echo ' true';
                                                    $countDan++;
                                                }
                                            }
                                            
                                            $count3 = count($alltrans->where('product_id', $item3->id));
                                        ?>
                                        <?php if($count > 0): ?>
                                            <?php if($count3 != 0): ?>
                                                <?php if($minSupport < number_format(($count / $total) * 100)): ?>
                                                    <?php if(($minCf < number_format(($countDan / $count3) * 100)) ): ?> <tr>
                                                        <td><?php echo e($item1->name . ', ' . $item2->name . ' => ' . $item3->name); ?>

                                                        </td>

                                                        <td><?php echo e($count); ?></td>
                                                        <td><?php echo e($total); ?></td>

                                                        
                                                        <td><?php echo e(number_format(($count / $total) * 100) . '%'); ?>

                                                        </td>

                                                        
                                                        <td><?php echo e(number_format(($countDan / $count3) * 100) . '%'); ?>

                                                        </td>
                                                        </tr>
                                                <?php endif; ?>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php endif; ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>



        <?php endif; ?>


    </div> <!-- end card-box -->
</div> <!-- end col-->
</div>
<!-- end row -->
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/perhitungan/perhitungan.blade.php ENDPATH**/ ?>