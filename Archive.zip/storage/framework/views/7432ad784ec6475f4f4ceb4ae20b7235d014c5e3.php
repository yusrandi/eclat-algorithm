<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <div class="dropdown float-right">
                <a href="#" class="dropdown-toggle arrow-none card-drop" data-toggle="dropdown" aria-expanded="false">
                    <i class="mdi mdi-dots-vertical"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Sales Report</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Export Report</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Profit</a>
                    <!-- item-->
                    <a href="javascript:void(0);" class="dropdown-item">Action</a>
                </div>
            </div>

            <h4 class="header-title mb-0">Total Users</h4>

            <!--  Modal content for the Large example -->
            <div class="modal fade" id="custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create')->html();
} elseif ($_instance->childHasBeenRendered('6nrbEEt')) {
    $componentId = $_instance->getRenderedChildComponentId('6nrbEEt');
    $componentTag = $_instance->getRenderedChildComponentTagName('6nrbEEt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6nrbEEt');
} else {
    $response = \Livewire\Livewire::mount('user.create');
    $html = $response->html();
    $_instance->logRenderedChild('6nrbEEt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

            <button wire:click="create" type="button" class="btn btn-soft-info waves-effect waves-light mt-3 mb-3"
                data-toggle="modal"><i class="mdi mdi-briefcase-plus-outline mr-1"></i>
                Add New User</button>

            <?php if($users->count()): ?>
                <div class="table-responsive">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                            <tr>

                                <th>#</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Email</th>
                                <th>Hak Akses</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <img class="rounded-circle" src="<?php echo e(url('storage/photos_thumb', $u->image)); ?>"
                                            alt="Image" style="height: 50px; width: 50px;">

                                    </td>
                                    <td><?php echo e($u->name); ?></td>

                                    <td>
                                        <?php echo e($u->phone); ?>

                                    </td>
                                    <td>
                                        <?php echo e($u->address); ?>

                                    </td>

                                    <td>
                                        <?php echo e($u->email); ?>

                                    </td>

                                    <td><?php echo e($u->role_id == '1' ? ($u->role_id == '1' ? 'Admin' : 'Kasir') : ($u->role_id == '2' ? 'Kasir' : 'Customer')); ?>

                                    </td>

                                    <td>


                                        <button wire:click="selectedItem(<?php echo e($u->id); ?>, 'update')" type="button"
                                            class="btn btn-soft-success waves-effect waves-light "><i
                                                class="mdi mdi-briefcase-edit-outline"></i></button>
                                        <button wire:click="selectedItem(<?php echo e($u->id); ?>, 'delete')" type="button"
                                            class="btn btn-soft-danger waves-effect waves-light"><i
                                                class="mdi mdi-briefcase-remove-outline"></i></button>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

            <?php endif; ?>


        </div> <!-- end card-box -->
    </div> <!-- end col-->
</div>
<!-- end row -->
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/user/index.blade.php ENDPATH**/ ?>