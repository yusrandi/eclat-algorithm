<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel">User Form</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

    </div>
    <div class="modal-body">
        <form class="needs-validation" novalidate>
            <div class="form-group">
                <label for="hori-pass1" class="col-sm-4 control-label">Foto User <span
                        class="text-danger">*</span></label>
                <div class="col-sm-12">
                    <input class="form-control" type="file" id="formFile" wire:model="image">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($image): ?>
                        <img src="<?php echo e($image->temporaryUrl()); ?>" height="200px" class="mt-2 mb-2 text-center">
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">Product Name <span class="text-danger">*</span>
                </label>
                <div class="col-sm-12">
                    <input wire:model="name" type="text" class="form-control" id="name" placeholder="e.g : Asep Udin">
                    <?php if($errors->has('name')): ?>
                        <small class="mt-2 text-danger"><?php echo e($errors->first('name')); ?></small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">Price <span class="text-danger">*</span>
                </label>
                <div class="col-sm-6">
                    <input wire:model="price" type="number" class="form-control" id="price" placeholder="e.g : 25000">
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">Stock <span class="text-danger">*</span>
                </label>
                <div class="col-sm-6">
                    <input wire:model="stock" type="number" class="form-control" id="stock" placeholder="e.g : 25">
                    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-soft-danger" data-dismiss="modal">Close</button>
        <button wire:click="save" type="submit" class="btn btn-soft-secondary">Submit</button>
    </div>
</div><!-- /.modal-content -->
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/product/create.blade.php ENDPATH**/ ?>