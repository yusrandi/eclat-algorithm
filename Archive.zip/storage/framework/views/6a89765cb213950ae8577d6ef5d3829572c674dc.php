<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel">User Form</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

    </div>
    <div class="modal-body">
        <form class="needs-validation" novalidate>
            <div class="form-group">
                <label for="hori-pass1" class="col-sm-4 control-label">Foto User <span
                        class="text-danger">*</span></label>
                <div class="col-sm-12">
                    <input class="form-control" type="file" id="formFile" wire:model="image">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($image): ?>
                        <img src="<?php echo e($image->temporaryUrl()); ?>" height="200px">
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">Fullname <span class="text-danger">*</span>
                </label>
                <div class="col-sm-12">
                    <input wire:model="name" type="text" class="form-control" id="name" placeholder="e.g : Asep Udin">
                    <?php if($errors->has('name')): ?>
                        <small class="mt-2 text-danger"><?php echo e($errors->first('name')); ?></small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">User Phone Number <span
                        class="text-danger">*</span>
                </label>
                <div class="col-sm-12">
                    <input wire:model="phone" type="text" class="form-control" id="name" placeholder="e.g : 0897xxx">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">User Address <span class="text-danger">*</span>
                </label>
                <div class="col-sm-12">
                    <input wire:model="address" type="text" class="form-control" id="name"
                        placeholder="e.g : Bps Sudiang">
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">Email <span class="text-danger">*</span></label>
                <div class="col-sm-12">
                    <input wire:model="email" type="email" class="form-control" id="inputEmail3"
                        placeholder="e.g : google@gmail.com" autocomplete="off"
                        <?php echo e($selectedItemId ? 'readonly' : ''); ?>>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label for="hori-pass1"
                    class="col-sm-4 control-label"><?php echo e($selectedItemId ? 'New Password ?' : 'Passowrd'); ?><span
                        class="text-danger">*</span></label>
                <div class="col-sm-12">
                    <input wire:model="password" id="hori-pass1" type="password" placeholder="Password"
                        class="form-control" autocomplete="new-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-soft-danger" data-dismiss="modal">Close</button>
        <button wire:click="save" type="submit" class="btn btn-soft-secondary">Submit</button>
    </div>
</div><!-- /.modal-content -->
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/user/create.blade.php ENDPATH**/ ?>