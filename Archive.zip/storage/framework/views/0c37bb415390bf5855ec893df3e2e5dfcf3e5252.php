<div>
    <!--  Modal content for the Large example -->
    <div class="modal fade" id="custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.create')->html();
} elseif ($_instance->childHasBeenRendered('S7ksb3K')) {
    $componentId = $_instance->getRenderedChildComponentId('S7ksb3K');
    $componentTag = $_instance->getRenderedChildComponentTagName('S7ksb3K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('S7ksb3K');
} else {
    $response = \Livewire\Livewire::mount('product.create');
    $html = $response->html();
    $_instance->logRenderedChild('S7ksb3K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-lg-8">
                        <form class="form-inline">
                            <div class="form-group">
                                <label for="inputPassword2" class="sr-only">Search</label>
                                <input type="search" class="form-control" id="inputPassword2" placeholder="Search...">
                            </div>
                            <div class="form-group mx-sm-3">
                                <label for="status-select" class="mr-2">Sort By</label>
                                <select class="custom-select" id="status-select">
                                    <option selected="">All</option>
                                    <option value="1">Popular</option>
                                    <option value="2">Price Low</option>
                                    <option value="3">Price High</option>
                                    <option value="4">Sold Out</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <button type="button" class="btn btn-success waves-effect waves-light mr-1"><i
                                    class="mdi mdi-cog"></i></button>
                            <button wire:click="create" class="btn btn-soft-info waves-effect waves-light"><i
                                    class="mdi mdi-plus-circle mr-1"></i> Add New</button>
                        </div>
                    </div><!-- end col-->
                </div> <!-- end row -->
            </div> <!-- end card-box -->
        </div> <!-- end col-->
    </div>
    <!-- end row-->

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-xl-3">
                <div class="card-box product-box">

                    <div class="product-action">
                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'update')"
                            class="btn btn-success btn-xs waves-effect waves-light"><i
                                class="mdi mdi-pencil"></i></button>
                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'delete')"
                            class="btn btn-danger btn-xs waves-effect waves-light"><i
                                class="mdi mdi-close"></i></button>
                    </div>

                    <div class="bg-light">
                        <img src="<?php echo e(url('storage/products_photo_thumb', $item->image)); ?>" alt="product-pic"
                            class="img-fluid" style="height: 250px" />
                    </div>

                    <div class="product-info">
                        <div class="row align-items-center">
                            <div class="col">
                                <h5 class="font-16 mt-0 sp-line-1"><a href="ecommerce-product-detail.html"
                                        class="text-dark"><?php echo e($item->name); ?></a> </h5>
                                <div class="text-warning mb-2 font-13">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <h5 class="m-0"> <span class="text-muted"> Rp.
                                        <?php echo e(number_format($item->price)); ?></span></h5>
                            </div>
                            <div class="col-auto">
                                <div class="product-price-tag">
                                    <?php echo e($item->stock); ?>

                                </div>
                            </div>
                        </div> <!-- end row -->
                    </div> <!-- end product info-->
                </div> <!-- end card-box-->
            </div> <!-- end col-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
<?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/livewire/product/index.blade.php ENDPATH**/ ?>