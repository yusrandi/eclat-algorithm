<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/libs/dropzone/min/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a
                                    href="javascript: void(0);"><?php echo e(config('app.name', 'Manyyu')); ?></a></li>
                            <li class="breadcrumb-item active">Products Data</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Products Data</h4>
                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.index')->html();
} elseif ($_instance->childHasBeenRendered('eG5W0Re')) {
    $componentId = $_instance->getRenderedChildComponentId('eG5W0Re');
    $componentTag = $_instance->getRenderedChildComponentTagName('eG5W0Re');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eG5W0Re');
} else {
    $response = \Livewire\Livewire::mount('product.index');
    $html = $response->html();
    $_instance->logRenderedChild('eG5W0Re', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(asset('assets/libs/dropzone/min/dropzone.min.js')); ?>"></script>

        <!-- Init js-->
        <script src="<?php echo e(asset('assets/js/pages/form-fileuploads.init.js')); ?>"></script>

        <!-- Init js -->
        <script src="<?php echo e(asset('assets/js/pages/add-product.init.js')); ?>"></script>
        <script>
            window.addEventListener('openModal', event => {
                $("#custom-modal").modal('show');

            });
            window.addEventListener('closeModal', event => {
                $("#custom-modal").modal('hide');

            });

        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#custom-modal").on('hidden.bs.modal', function() {
                    livewire.emit('forceCloseModal');
                });


            });

        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Products Data'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/mannyu/resources/views/pages/products.blade.php ENDPATH**/ ?>