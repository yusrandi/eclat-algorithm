<?php return array (
  'perhitungan.perhitungan' => 'App\\Http\\Livewire\\Perhitungan\\Perhitungan',
  'product.create' => 'App\\Http\\Livewire\\Product\\Create',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
  'sale.create' => 'App\\Http\\Livewire\\Sale\\Create',
  'sale.index' => 'App\\Http\\Livewire\\Sale\\Index',
  'user.create' => 'App\\Http\\Livewire\\User\\Create',
  'user.index' => 'App\\Http\\Livewire\\User\\Index',
);